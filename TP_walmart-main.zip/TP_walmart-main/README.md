# TP_walmart: Utilisation de l'API dataframe
Ce TP consiste à répondre aux questions contenues dans le fichier  [walmart_stock](https://docs.google.com/document/d/12DvCjelzdr-Ws_6sQ8DK2yVV5jw5ELAM1anXLllNbp4/edit) en utilisant d’abord une commande pyspark et ensuite une commande sql.
Les questions traitées dans ce projet sont les question 5 à 12, Le reste étant déjà vu en cours. 

## Instructions
:arrow_forward: Télecharger le fichier walmart_script.py dans le repertoire script.  

:arrow_forward: Télecharger les **données** disponible dans le repertoire Data.

:arrow_forward: ouvrir l'invité de commande et se placer dans le même repertoire avec la commande **cd**.

:arrow_forward:Ecrire l'instruction: 

     "spark-submit walmart_script.py"

:arrow_forward: Les differentes réponses s'afficheront progressivement.
